/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Monkey extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("monkey-a", "./Monkey/costumes/monkey-a.svg", {
        x: 68,
        y: 99
      }),
      new Costume("monkey-b", "./Monkey/costumes/monkey-b.svg", {
        x: 68,
        y: 99
      }),
      new Costume("monkey-c", "./Monkey/costumes/monkey-c.svg", {
        x: 68,
        y: 99
      })
    ];

    this.sounds = [
      new Sound("Chee Chee", "./Monkey/sounds/Chee Chee.wav"),
      new Sound("Chomp", "./Monkey/sounds/Chomp.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CUT UP MONKEY" },
        this.whenIReceiveCutUpMonkey
      )
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, -80);
    this.direction = 90;
    this.visible = true;
  }

  *whenthisspriteclicked() {
    this.broadcast("CUT UP MONKEY");
  }

  *whenIReceiveCutUpMonkey() {
    this.visible = false;
  }
}
