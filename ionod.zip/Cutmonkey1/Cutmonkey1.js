/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Cutmonkey1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("monkey-a", "./Cutmonkey1/costumes/monkey-a.svg", {
        x: 68,
        y: 99
      }),
      new Costume("monkey-a2", "./Cutmonkey1/costumes/monkey-a2.svg", {
        x: 82.5,
        y: 81
      }),
      new Costume("monkey-b", "./Cutmonkey1/costumes/monkey-b.svg", {
        x: 68,
        y: 99
      }),
      new Costume("monkey-b2", "./Cutmonkey1/costumes/monkey-b2.png", {
        x: 148,
        y: 172
      }),
      new Costume("monkey-c", "./Cutmonkey1/costumes/monkey-c.svg", {
        x: 68,
        y: 99
      }),
      new Costume("monkey-c2", "./Cutmonkey1/costumes/monkey-c2.png", {
        x: 151,
        y: 167
      })
    ];

    this.sounds = [
      new Sound("Chomp", "./Cutmonkey1/sounds/Chomp.wav"),
      new Sound("Screech", "./Cutmonkey1/sounds/Screech.wav"),
      new Sound("G Elec Bass", "./Cutmonkey1/sounds/G Elec Bass.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone)
    ];

    this.vars.myxvelocity = -1;
    this.vars.myyvelocity = -18;
    this.vars.myRotation = -1;
    this.vars.chopped = "true";
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.visible = false;
    this.costume = this.random(1, 3) * 2 - 1;
    this.y = -180;
    this.x = this.random(-200, 200);
    this.direction = 90;
    this.vars.myxvelocity = this.random(-5, 5);
    this.vars.myyvelocity = this.random(10, 25);
    this.vars.myRotation = this.random(-5, 5);
    this.vars.chopped = "false";
    this.visible = true;
    while (!(this.y < -181)) {
      this.direction += this.vars.myRotation;
      this.x += this.vars.myxvelocity;
      this.y += this.vars.myyvelocity;
      yield* this.wait(0.05);
      this.vars.myyvelocity += -1;
      if (
        this.touching("mouse") &&
        this.mouse.down &&
        this.vars.chopped == "false"
      ) {
        this.costumeNumber += 1;
        this.vars.chopped = "true";
        yield* this.startSound("Screech");
      }
      yield;
    }
    if (this.vars.chopped == "true") {
      this.stage.vars.score += 1;
    } else {
      this.stage.vars.lives += -1;
      yield* this.startSound("G Elec Bass");
    }
    this.visible = false;
    this.deleteThisClone();
  }
}
