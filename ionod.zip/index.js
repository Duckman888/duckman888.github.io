import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Sprite1 from "./Sprite1/Sprite1.js";
import Monkey from "./Monkey/Monkey.js";
import Cutmonkey1 from "./Cutmonkey1/Cutmonkey1.js";
import GsmerOver from "./GsmerOver/GsmerOver.js";
import Knife from "./Knife/Knife.js";
import Duckduxk from "./Duckduxk/Duckduxk.js";

const stage = new Stage({ costumeNumber: 3 });

const sprites = {
  Sprite1: new Sprite1({
    x: 0,
    y: 110,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 1
  }),
  Monkey: new Monkey({
    x: 0,
    y: -80,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 2
  }),
  Cutmonkey1: new Cutmonkey1({
    x: -107,
    y: -197,
    direction: 56,
    costumeNumber: 2,
    size: 100,
    visible: false,
    layerOrder: 3
  }),
  GsmerOver: new GsmerOver({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 4
  }),
  Knife: new Knife({
    x: -240,
    y: -99,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 6
  }),
  Duckduxk: new Duckduxk({
    x: -176,
    y: -194,
    direction: -94,
    costumeNumber: 2,
    size: 100,
    visible: false,
    layerOrder: 5
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
